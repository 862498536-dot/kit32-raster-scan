param([Parameter(Mandatory=$true)][ValidatePattern('^COM[0-9]+$')][string]$Port)
$ErrorActionPreference = 'Stop'
$cliPath = 'C:\Users\86249\AppData\Local\Programs\arduino-ide\resources\app\lib\backend\resources\arduino-cli.exe'
$firmwarePath = Join-Path $PSScriptRoot 'firmware'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'firmware-sha256.json') -Raw | ConvertFrom-Json
foreach ($entry in $manifest) {
    $actual = (Get-FileHash -LiteralPath (Join-Path $firmwarePath $entry.file) -Algorithm SHA256).Hash
    if ($actual -ne $entry.sha256) { throw "Firmware checksum mismatch: $($entry.file)" }
}
$device = Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match ('CH9102.*\(' + [regex]::Escape($Port) + '\)') -and $_.Status -eq 'OK' }
if (-not $device) { throw "No ready CH9102 device on $Port. Check the robot and USB cable." }
Write-Host "Uploading saved Kit32 firmware to $($device.Name)..."
& $cliPath upload --port $Port --fqbn 'm5stack:esp32:m5stack_stamp_c3:CDCOnBoot=default' --input-dir $firmwarePath
if ($LASTEXITCODE -ne 0) { throw 'Upload failed. See the Arduino output above.' }
Write-Host 'Upload verified. Robot will restart and wait for a start command.'
