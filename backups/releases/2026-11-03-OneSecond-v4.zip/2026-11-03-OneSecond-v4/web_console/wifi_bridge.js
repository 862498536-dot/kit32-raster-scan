// Local-only bridge: browser WebSocket <-> Kit32 raw TCP telemetry stream.
// The browser cannot directly open a TCP socket, so this stays on 127.0.0.1.
const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const LOCAL_PORT = 8766;
const ROBOT_HOST = process.env.KIT32_HOST || '192.168.137.46';
const ROBOT_PORT = 80;
const pagePath = path.join(__dirname, 'index.html');

function sendFrame(socket, payload) {
  const data = Buffer.from(payload);
  const header = data.length < 126
    ? Buffer.from([0x81, data.length])
    : Buffer.from([0x81, 126, data.length >> 8, data.length & 0xff]);
  socket.write(Buffer.concat([header, data]));
}

function sendText(socket, text) { if (!socket.destroyed) sendFrame(socket, text); }

function parseClientFrames(client, robot, state) {
  while (state.buffer.length >= 2) {
    const opcode = state.buffer[0] & 15;
    if (opcode === 8) { robot.destroy(); client.end(Buffer.from([0x88,0])); return; }
    const second = state.buffer[1];
    const masked = (second & 0x80) !== 0;
    let length = second & 0x7f;
    if (length === 127) { client.destroy(); return; }
    let offset = 2;
    if (length === 126) { if (state.buffer.length < 4) return; length = state.buffer.readUInt16BE(2); offset = 4; }
    if (!masked || state.buffer.length < offset + 4 + length) return;
    const mask = state.buffer.subarray(offset, offset + 4); offset += 4;
    const data = Buffer.alloc(length);
    for (let i = 0; i < length; i++) data[i] = state.buffer[offset + i] ^ mask[i % 4];
    state.buffer = state.buffer.subarray(offset + length);
    if (opcode === 1 && /^(START|STOP|PING)\n$/.test(data.toString()) && robot.writable) robot.write(data);
  }
}

const server = http.createServer((request, response) => {
  if (request.url === '/config') { response.writeHead(200, {'Content-Type':'application/json','Cache-Control':'no-store'}); response.end(JSON.stringify({host:ROBOT_HOST})); return; }
  if (request.url !== '/' && request.url !== '/index.html') { response.writeHead(404); response.end('Not found'); return; }
  response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(pagePath).pipe(response);
});

server.on('upgrade', (request, client, head) => {
  const url = new URL(request.url, 'http://127.0.0.1');
  const host = url.searchParams.get('host') || ROBOT_HOST;
  const origin = request.headers.origin;
  if (url.pathname !== '/ws' || !request.headers['sec-websocket-key'] || !/^192\.168\.137\.(\d{1,3})$/.test(host) || Number(host.split('.').pop()) > 254 || !['http://127.0.0.1:8766','http://localhost:8766','http://127.0.0.1:8765'].includes(origin)) { client.destroy(); return; }
  const accept = crypto.createHash('sha1').update(request.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  client.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
  const robot = net.createConnection({ host, port: ROBOT_PORT });
  const frameState = { buffer: head.length ? Buffer.from(head) : Buffer.alloc(0) };
  robot.setNoDelay(true);
  robot.setTimeout(5000);
  robot.on('timeout', () => { sendText(client, 'BRIDGE,ROBOT_ERROR,TIMEOUT\n'); robot.destroy(); });
  robot.on('connect', () => { sendText(client, 'BRIDGE,ROBOT_CONNECTED\n'); robot.write('PING\n'); });
  robot.on('data', (data) => sendText(client, data));
  robot.on('error', (error) => sendText(client, `BRIDGE,ROBOT_ERROR,${error.code || error.message}\n`));
  robot.on('close', () => { sendText(client, 'BRIDGE,ROBOT_DISCONNECTED\n'); client.end(Buffer.from([0x88,0])); });
  client.on('data', (data) => { frameState.buffer = Buffer.concat([frameState.buffer, data]); parseClientFrames(client, robot, frameState); });
  client.on('close', () => robot.destroy());
  client.on('error', () => robot.destroy());
});

server.listen(LOCAL_PORT, '127.0.0.1', () => console.log(`Kit32 Wi-Fi console: http://127.0.0.1:${LOCAL_PORT}/`));
