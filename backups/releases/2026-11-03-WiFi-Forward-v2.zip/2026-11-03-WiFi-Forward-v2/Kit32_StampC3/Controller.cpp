#include "Controller.h"

const unsigned long Controller_c::UPDATE_INTERVAL_MS;
const unsigned long Controller_c::TELEMETRY_INTERVAL_MS;
const unsigned long Controller_c::START_ALIGN_TIMEOUT_MS;
const uint8_t Controller_c::START_ALIGN_CONFIRM_SAMPLES;
const uint16_t Controller_c::LINE_THRESHOLD;
constexpr float Controller_c::BASE_PWM;
constexpr float Controller_c::START_ALIGN_LEFT_PWM;
constexpr float Controller_c::START_ALIGN_RIGHT_PWM;

Controller_c::Controller_c()
  : update_timer(UPDATE_INTERVAL_MS),
    telemetry_timer(TELEMETRY_INTERVAL_MS) {
  reset();
}

void Controller_c::reset() {
  signal = 0;
  mode = WAITING;
  alignment_start_ms = 0;
  alignment_hits = 0;

}

uint8_t Controller_c::getSignal() const {
  return signal;
}

void Controller_c::start() {
  if (signal == 0 || mode == STOPPED) {
    reset();
    setSignal(1);
  }
}

void Controller_c::stop(Robot_c &robot) {
  robot.setMotorPWM(0, 0);
  reset();
}

void Controller_c::setSignal(uint8_t requested_signal) {
  if (requested_signal == 0) {
    reset();
    return;
  }

  if (signal == 0) {
    signal = 1;
    // The black tape must be a one-sided radial strip that points from the
    // starting circle towards the intended departure direction. While the
    // robot rotates, DN3 sweeps a circle and sees the tape only at that heading.
    mode = ALIGNING_TO_START_TAPE;
    alignment_start_ms = 0;
    alignment_hits = 0;
  }
}

void Controller_c::update(Robot_c &robot, RobotWifiAP_c &server) {

  // Get the current count of milliseconds since the StampC3 was powered on.
  unsigned long now = robot.getMillis();

  // Check if our TaskTimer_c for the general controller update indicates
  // that it is the correct time to operate.  Note, we give the TaskTimer_c
  // the current count in milliseconds.
  // We do this because we don't want to query the robot faster than at 10ms
  // intervals.
  if (!update_timer.isReady(now)) {

    // TaskTimer_c says it is not ready, so we simply end this call to
    // the controller here by calling return.
    return;
  }

  // The TaskTimer_c was ready, so we now reset the TaskTimer_c so it
  // begins counting again.  We now run the remaining controller code.
  update_timer.resetTimer(now);

  // Ask the robot for latest information on surface reflectance sensors.
  robot.getSurfaceSensors();

  // Ask the robot for the latest encoder information, and then use this
  // to update the odometry on board the StampC3 (see OdometryModel.h).
  if (robot.getEncoders()) {
    odometry.update(robot.getLeftEncoderCount(), robot.getRightEncoderCount());
  }

  // Pose estimation from the Pololu 3Pi robot itself.
  robot.getPose();

  // First button press starts the direction-alignment routine. If it has
  // timed out, a later press starts a fresh attempt without rebooting.
  if (robot.isButtonPressed()) {
    start();
  }

  // The tape is a start-direction marker only. After alignment, drive forward.
  if (signal == 1) {
    runStartController(robot, now);

  }

  // Use another TaskTimer_c to limit how often we transmit telemetry data
  // on WiFi and Serial.
  if (telemetry_timer.isReady(now)) {
    telemetry_timer.resetTimer(now);
    publishTelemetry(robot, server, now);

  }
}

bool Controller_c::lineDetected(const Robot_c &robot) const {
  // Note: only using the central sensor to detect a line.
  if (robot.surface.reading[2] >= LINE_THRESHOLD) {
    return true;
  }

  return false;
}

void Controller_c::runStartController(Robot_c &robot, unsigned long now) {
  if (mode == ALIGNING_TO_START_TAPE) {
    if (alignment_start_ms == 0) {
      alignment_start_ms = now;
    }

    if (lineDetected(robot)) {
      alignment_hits++;
    } else {
      alignment_hits = 0;
    }

    // Require several samples so a small black speck cannot trigger launch.
    if (alignment_hits >= START_ALIGN_CONFIRM_SAMPLES) {
      mode = DRIVING_FORWARD;
      robot.setMotorPWM(0, 0);
      return;
    }

    if (now - alignment_start_ms >= START_ALIGN_TIMEOUT_MS) {
      mode = STOPPED;
      robot.setMotorPWM(0, 0);
      return;
    }

    robot.setMotorPWM(START_ALIGN_LEFT_PWM, START_ALIGN_RIGHT_PWM);
    return;
  }

  if (mode == DRIVING_FORWARD) {
    // White ground is expected after leaving the marker. No line recovery or
    // reflectance steering applies here. Wheel mismatch can still cause drift.
    robot.setMotorPWM(BASE_PWM, BASE_PWM);
  } else {
    robot.setMotorPWM(0, 0);
  }
}

void Controller_c::publishTelemetry(Robot_c &robot, RobotWifiAP_c &server, unsigned long timestamp_ms) {
  server.printf(
    "%lu,%.2f,%.2f,%.5f,%d,%d,%ld,%ld,%u,%u,%u,%u,%u,%u\n",
    timestamp_ms,
    odometry.pose.x,
    odometry.pose.y,
    odometry.pose.theta,
    robot.getLeftMotorPWM(),
    robot.getRightMotorPWM(),
    (long)robot.getLeftEncoderCount(),
    (long)robot.getRightEncoderCount(),
    robot.surface.reading[0],
    robot.surface.reading[1],
    robot.surface.reading[2],
    robot.surface.reading[3],
    robot.surface.reading[4],
    signal
  );
  if ( Serial ) { // If serial is connected
    Serial.printf(
      "%lu,%.2f,%.2f,%.5f,%d,%d,%ld,%ld,%u,%u,%u,%u,%u,%u\n",
      timestamp_ms,
      odometry.pose.x,
      odometry.pose.y,
      odometry.pose.theta,
      robot.getLeftMotorPWM(),
      robot.getRightMotorPWM(),
      (long)robot.getLeftEncoderCount(),
      (long)robot.getRightEncoderCount(),
      robot.surface.reading[0],
      robot.surface.reading[1],
      robot.surface.reading[2],
      robot.surface.reading[3],
      robot.surface.reading[4],
      signal
    );
  }
}
